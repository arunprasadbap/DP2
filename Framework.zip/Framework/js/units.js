/*global angular*/
var app = angular.module('myApp', ['ngRoute']);

app.config(['$routeProvider', function ($routeProvider) {
    "use strict";
    $routeProvider.
        when('/Details/:id', {
            templateUrl: 'myTemplate/myTemplate.html',
            controller: 'detailsController'
        });
}]);
app.controller('detailsController', function ($scope, $routeParams) {
    "use strict";
    $scope.code = $routeParams.id;
});